import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:notes_tasks/core/app/routs/app_routes.dart';
import 'package:notes_tasks/core/shared/widgets/common/app_scaffold.dart';
import 'package:notes_tasks/core/shared/constants/spacing.dart';
import 'package:notes_tasks/core/app/theme/text_styles.dart';
import 'package:notes_tasks/modules/chat/presentation/providers/chat_stream_provider.dart';

class ChatDetailsArgs {
  final String chatId;
  const ChatDetailsArgs({required this.chatId});
}

class ChatsListPage extends ConsumerWidget {
  const ChatsListPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(myChatsStreamProvider);

    return AppScaffold(
      scrollable: false,
      title: 'Chats',
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (chats) {
          if (chats.isEmpty) {
            return const Center(child: Text('No chats yet'));
          }

          return ListView.separated(
            padding: EdgeInsets.all(AppSpacing.spaceMD),
            itemCount: chats.length,
            separatorBuilder: (_, __) => SizedBox(height: AppSpacing.spaceMD),
            itemBuilder: (_, i) {
              final c = chats[i];

              return InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () {
                  context.push(
                    AppRoutes.chatDetails,
                    extra: ChatDetailsArgs(chatId: c.id),
                  );
                },
                child: Container(
                  padding: EdgeInsets.all(AppSpacing.spaceMD),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Theme.of(context).dividerColor),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundImage: c.jobCoverUrl == null
                            ? null
                            : NetworkImage(c.jobCoverUrl!),
                        child: c.jobCoverUrl == null
                            ? const Icon(Icons.work_outline)
                            : null,
                      ),
                      SizedBox(width: AppSpacing.spaceMD),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(c.jobTitle,
                                style: AppTextStyles.body
                                    .copyWith(fontWeight: FontWeight.w700)),
                            SizedBox(height: AppSpacing.spaceXS),
                            Text(
                              c.lastMessageText ?? 'No messages yet',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTextStyles.caption,
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right,
                          color: Theme.of(context).hintColor),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
