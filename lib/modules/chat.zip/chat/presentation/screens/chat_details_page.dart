import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:notes_tasks/core/shared/constants/spacing.dart';
import 'package:notes_tasks/core/app/theme/text_styles.dart';
import 'package:notes_tasks/modules/chat/presentation/providers/chat_stream_provider.dart';

import '../viewmodels/chat_actions_viewmodel.dart';

class ChatDetailsPage extends ConsumerStatefulWidget {
  final String chatId;
  const ChatDetailsPage({super.key, required this.chatId});

  @override
  ConsumerState<ChatDetailsPage> createState() => _ChatDetailsPageState();
}

class _ChatDetailsPageState extends ConsumerState<ChatDetailsPage> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final messagesAsync = ref.watch(chatMessagesStreamProvider(widget.chatId));
    final vm = ref.read(chatActionsViewModelProvider.notifier);
    final sending = ref.watch(chatActionsViewModelProvider).isLoading;

    return Scaffold(
      appBar: AppBar(title: const Text('Chat')),
      body: Column(
        children: [
          Expanded(
            child: messagesAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Error: $e')),
              data: (messages) {
                if (messages.isEmpty) {
                  return const Center(child: Text('Say hi 👋'));
                }
                return ListView.builder(
                  padding: EdgeInsets.all(AppSpacing.spaceMD),
                  itemCount: messages.length,
                  itemBuilder: (_, i) {
                    final m = messages[i];
                    return Padding(
                      padding: EdgeInsets.only(bottom: AppSpacing.spaceSM),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          padding: EdgeInsets.all(AppSpacing.spaceSM),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: Theme.of(context).dividerColor),
                          ),
                          child: Text(m.text, style: AppTextStyles.body),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // input
          SafeArea(
            child: Padding(
              padding: EdgeInsets.all(AppSpacing.spaceMD),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      decoration:
                          const InputDecoration(hintText: 'Type a message...'),
                    ),
                  ),
                  SizedBox(width: AppSpacing.spaceSM),
                  IconButton(
                    onPressed: sending
                        ? null
                        : () async {
                            final text = _ctrl.text;
                            _ctrl.clear();
                            await vm.send(context,
                                chatId: widget.chatId, text: text);
                          },
                    icon: sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
