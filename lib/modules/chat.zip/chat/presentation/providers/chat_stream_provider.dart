import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/modules/chat/domain/entities/chat_entity.dart';
import 'package:notes_tasks/modules/chat/domain/entities/message_entity.dart';
import 'package:notes_tasks/modules/chat/presentation/providers/chat_usecases_providers.dart';

final myChatsStreamProvider = StreamProvider<List<ChatEntity>>((ref) {
  final uc = ref.read(watchMyChatsUseCaseProvider);
  return uc();
});

final chatMessagesStreamProvider =
    StreamProvider.family<List<MessageEntity>, String>((ref, chatId) {
  final uc = ref.read(watchMessagesUseCaseProvider);
  return uc(chatId);
});
