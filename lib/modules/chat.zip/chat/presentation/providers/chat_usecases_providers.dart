import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/core/features/chat/chat_provider.dart';
import 'package:notes_tasks/modules/chat/domain/usecases/send_message_usecase.dart';
import 'package:notes_tasks/modules/chat/domain/usecases/watch_messages_usecase.dart';
import 'package:notes_tasks/modules/chat/domain/usecases/watch_my_chats_usecase.dart';

final watchMyChatsUseCaseProvider = Provider<WatchMyChatsUseCase>((ref) {
  final service = ref.read(chatsServiceProvider);
  return WatchMyChatsUseCase(service);
});

final watchMessagesUseCaseProvider = Provider<WatchMessagesUseCase>((ref) {
  final service = ref.read(chatsServiceProvider);
  return WatchMessagesUseCase(service);
});

final sendMessageUseCaseProvider = Provider<SendMessageUseCase>((ref) {
  final service = ref.read(chatsServiceProvider);
  return SendMessageUseCase(service);
});
