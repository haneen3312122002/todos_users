import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/core/shared/widgets/common/app_snackbar.dart';
import 'package:notes_tasks/modules/chat/presentation/providers/chat_usecases_providers.dart';

final chatActionsViewModelProvider =
    AsyncNotifierProvider<ChatActionsViewModel, void>(ChatActionsViewModel.new);

class ChatActionsViewModel extends AsyncNotifier<void> {
  late final _send = ref.read(sendMessageUseCaseProvider);

  @override
  FutureOr<void> build() {}

  Future<void> send(BuildContext context,
      {required String chatId, required String text}) async {
    if (state.isLoading) return;
    state = const AsyncLoading();
    try {
      await _send(chatId: chatId, text: text);
      state = const AsyncData(null);
    } catch (e, st) {
      state = AsyncError(e, st);
      AppSnackbar.show(context, e.toString());
    }
  }
}
