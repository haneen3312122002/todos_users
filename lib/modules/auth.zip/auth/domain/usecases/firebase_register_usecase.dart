import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:notes_tasks/core/data/remote/firebase/providers/firebase_providers.dart';
import 'package:notes_tasks/core/features/auth/services/auth_service.dart';

final firebaseRegisterUseCaseProvider =
    Provider<FirebaseRegisterUseCase>((ref) {
  final authService = ref.read(authServiceProvider);
  return FirebaseRegisterUseCase(authService);
});

class FirebaseRegisterUseCase {
  final AuthService _authService;
  FirebaseRegisterUseCase(this._authService);

  Future<fb.UserCredential> call(
      {required String name,
      required String email,
      required String password,
      required String role}) {
    return _authService.register(
        name: name, email: email, password: password, role: role);
  }
}