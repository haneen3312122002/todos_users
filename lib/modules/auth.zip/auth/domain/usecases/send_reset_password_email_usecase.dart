import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:notes_tasks/core/data/remote/firebase/providers/firebase_providers.dart';
import 'package:notes_tasks/modules/auth/domain/failures/reset_password_failure.dart';

final sendResetPasswordEmailUseCaseProvider =
    Provider<SendResetPasswordEmailUseCase>((ref) {
  final auth = ref.read(firebaseAuthProvider);
  return SendResetPasswordEmailUseCase(auth);
});

class SendResetPasswordEmailUseCase {
  final fb.FirebaseAuth _auth;
  SendResetPasswordEmailUseCase(this._auth);

  Future<void> call({required String email}) async {
    try {
      await _auth
          .sendPasswordResetEmail(email: email)
          .timeout(const Duration(seconds: 20));
    } on fb.FirebaseAuthException catch (e) {
      final messageKey = _mapFirebaseErrorToMessageKey(e);
      throw ResetPasswordFailure(messageKey);
    } on TimeoutException {
      throw const ResetPasswordFailure('request_timeout');
    } catch (_) {
      throw const ResetPasswordFailure('something_went_wrong');
    }
  }

  String _mapFirebaseErrorToMessageKey(fb.FirebaseAuthException e) {
    switch (e.code) {
      case 'user-not-found':
        return 'user_not_found';
      case 'invalid-email':
        return 'invalid_email';
      case 'missing-email':
        return 'please_enter_email';
      case 'network-request-failed':
        return 'network_error';
      default:
        return 'something_went_wrong';
    }
  }
}