import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:notes_tasks/core/data/remote/firebase/providers/firebase_providers.dart';
import 'package:notes_tasks/core/features/auth/services/auth_service.dart';

final firebaseLoginUseCaseProvider = Provider<FirebaseLoginUseCase>((ref) {
  final authService = ref.read(authServiceProvider);
  return FirebaseLoginUseCase(authService);
});

class FirebaseLoginUseCase {
  final AuthService _authService;
  FirebaseLoginUseCase(this._authService);

  Future<fb.UserCredential> call({
    required String email,
    required String password,
  }) {
    return _authService.login(email: email, password: password);
  }
}