import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/core/data/remote/firebase/providers/firebase_providers.dart';
import 'package:notes_tasks/modules/auth/domain/failures/change_password_falures.dart';

final changePasswordUseCaseProvider = Provider<ChangePasswordUseCase>((ref) {
  final auth = ref.read(firebaseAuthProvider);
  return ChangePasswordUseCase(auth);
});

class ChangePasswordUseCase {
  final fb.FirebaseAuth _auth;

  ChangePasswordUseCase(this._auth);



  Future<void> call({
    required String currentPassword,
  }) async {
    final user = _auth.currentUser;
    if (user == null) {
      throw const ChangePasswordFailure('not_authenticated');
    }

    final email = user.email;
    if (email == null || email.isEmpty) {
      throw const ChangePasswordFailure('no_email_for_user');
    }

    try {

      final credential = fb.EmailAuthProvider.credential(
        email: email,
        password: currentPassword,
      );

      await user
          .reauthenticateWithCredential(credential)
          .timeout(const Duration(seconds: 20));


      await _auth
          .sendPasswordResetEmail(email: email)
          .timeout(const Duration(seconds: 20));
    } on fb.FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'wrong-password':
          throw const ChangePasswordFailure('wrong_current_password');
        case 'user-not-found':
          throw const ChangePasswordFailure('user_not_found');
        case 'too-many-requests':
          throw const ChangePasswordFailure('too_many_requests');
        default:
          throw const ChangePasswordFailure('something_went_wrong');
      }
    } on TimeoutException {
      throw const ChangePasswordFailure('request_timeout');
    } catch (_) {
      throw const ChangePasswordFailure('something_went_wrong');
    }
  }
}