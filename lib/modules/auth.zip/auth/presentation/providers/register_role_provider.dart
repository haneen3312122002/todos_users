import 'package:flutter_riverpod/legacy.dart';

final selectedRoleProvider = StateProvider<String?>((ref) => null);