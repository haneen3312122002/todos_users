import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/modules/auth/domain/failures/reset_password_failure.dart';
import 'package:notes_tasks/modules/auth/domain/usecases/send_reset_password_email_usecase.dart';

final resetPasswordViewModelProvider =
    AsyncNotifierProvider<ResetPasswordViewModel, void>(
  ResetPasswordViewModel.new,
);

class ResetPasswordViewModel extends AsyncNotifier<void> {
  @override
  FutureOr<void> build() async {
    return;
  }

  Future<void> sendResetEmail({
    required String email,
  }) async {
    if (state.isLoading) {
      debugPrint(
          '[ResetPasswordVM] Ignored duplicate sendResetEmail() while loading');
      return;
    }

    debugPrint('[ResetPasswordVM] Start sendResetEmail: email=$email');

    if (email.isEmpty) {
      debugPrint('[ResetPasswordVM] Validation failed: empty email');
      state = AsyncError(
        const ResetPasswordFailure('please_enter_email'),
        StackTrace.current,
      );
      return;
    }

    state = const AsyncLoading();
    final usecase = ref.read(sendResetPasswordEmailUseCaseProvider);

    try {
      await usecase(email: email);
      debugPrint('[ResetPasswordVM] sendResetEmail() completed for $email');
      state = const AsyncData(null);
    } on ResetPasswordFailure catch (e, st) {
      debugPrint('[ResetPasswordVM] ResetPasswordFailure: $e');
      state = AsyncError(e, st);
    } catch (e, st) {
      debugPrint('[ResetPasswordVM] Unknown error: $e');
      state = AsyncError(
        const ResetPasswordFailure('something_went_wrong'),
        st,
      );
    }
  }
}