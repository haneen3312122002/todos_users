import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:notes_tasks/modules/auth/domain/usecases/firebase_login_usecase.dart';
import 'package:notes_tasks/modules/auth/domain/usecases/logout_usecase.dart';

final firebaseLoginVMProvider =
    AsyncNotifierProvider<FirebaseLoginViewModel, fb.User?>(
  FirebaseLoginViewModel.new,
  name: 'FirebaseLoginVM',
);

class FirebaseLoginViewModel extends AsyncNotifier<fb.User?> {
  @override
  FutureOr<fb.User?> build() async => null;

  Future<void> login({required String email, required String password}) async {
    if (state.isLoading) return;
    debugPrint('[VM] login() called email=$email');
    state = const AsyncLoading();
    try {
      final loginUseCase = ref.read(firebaseLoginUseCaseProvider);
      final cred = await loginUseCase(email: email, password: password);
      debugPrint('[VM] usecase returned uid=${cred.user?.uid}');
      state = AsyncData(cred.user);
    } on fb.FirebaseAuthException catch (e, st) {
      debugPrint('[VM] FirebaseAuthException code=${e.code} msg=${e.message}');
      state = AsyncError(e, st);
    } catch (e, st) {
      debugPrint('[VM] Unknown error: $e');
      state = AsyncError(e, st);
    }
  }

  Future<void> logout() async {
    state = const AsyncLoading();
    try {
      final logoutUseCase = ref.read(logoutUseCaseProvider);
      await logoutUseCase();
      state = const AsyncData(null);
    } catch (e, st) {
      state = AsyncError(e, st);
    }
  }
}