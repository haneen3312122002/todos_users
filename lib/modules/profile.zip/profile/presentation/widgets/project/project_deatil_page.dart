import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:notes_tasks/core/shared/enums/page_mode.dart';
import 'package:notes_tasks/core/shared/widgets/common/app_snackbar.dart';

import 'package:notes_tasks/core/shared/widgets/pages/deatiles_page.dart';

import 'package:notes_tasks/modules/profile/domain/entities/project_entity.dart';

import 'package:notes_tasks/modules/profile/presentation/viewmodels/project/project_cover_image_viewmodel.dart';

import 'package:notes_tasks/modules/profile/presentation/services/project_image_helpers.dart';

class ProjectDetailsArgs {
  final ProjectEntity project;
  final PageMode mode;

  const ProjectDetailsArgs({
    required this.project,
    this.mode = PageMode.view,
  });
}

class ProjectDetailsPage extends ConsumerStatefulWidget {
  final ProjectEntity project;
  final PageMode mode;

  const ProjectDetailsPage({
    super.key,
    required this.project,
    this.mode = PageMode.view,
  });

  @override
  ConsumerState<ProjectDetailsPage> createState() => _ProjectDetailsPageState();
}

class _ProjectDetailsPageState extends ConsumerState<ProjectDetailsPage> {
  bool get _canEditHeader => widget.mode == PageMode.edit;

  @override
  void initState() {
    super.initState();

    ref.listen<AsyncValue<Uint8List?>>(
      projectCoverImageViewModelProvider(widget.project.id),
      (prev, next) {
        final wasLoading = prev?.isLoading ?? false;

        next.when(
          data: (_) {
            if (!wasLoading) return;
            if (!mounted) return;
            AppSnackbar.show(context, 'cover_image_updated'.tr());
          },
          loading: () {},
          error: (e, st) {
            if (!wasLoading) return;
            if (!mounted) return;
            AppSnackbar.show(
              context,
              'failed_with_error'.tr(namedArgs: {'error': e.toString()}),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasDescription = widget.project.description.trim().isNotEmpty;
    final hasTools = widget.project.tools.isNotEmpty;

    final coverAsync =
        ref.watch(projectCoverImageViewModelProvider(widget.project.id));

    final localCoverBytes = coverAsync.value; // bytes أو null

    return AppDetailsPage(
      mode: widget.mode,
      appBarTitleKey: 'project_details_title',
      coverImageUrl: widget.project.imageUrl,
      coverBytes: localCoverBytes,
      showAvatar: false,
      title: widget.project.title,
      subtitle: null,
      onChangeCover: _canEditHeader
          ? () {
              pickAndUploadProjectCover(
                context,
                ref,
                projectId: widget.project.id,
              );
            }
          : null,
      onChangeAvatar: null,
      sections: [
        if (hasDescription) ...[
          // نفس كودك
        ],
        if (hasTools) ...[
          // نفس كودك
        ],
      ],
    );
  }
}
