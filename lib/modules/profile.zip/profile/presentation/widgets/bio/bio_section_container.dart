import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:notes_tasks/modules/profile/presentation/providers/bio/bio_editing.dart';
import 'package:notes_tasks/modules/profile/presentation/providers/bio/bio_provider.dart';
import 'package:notes_tasks/modules/profile/presentation/viewmodels/bio/bio_form_viewmodel.dart';
import 'package:notes_tasks/modules/profile/presentation/widgets/bio/bio_section.dart';

class BioSectionContainer extends ConsumerWidget {
  const BioSectionContainer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bio = ref.watch(bioProvider);
    final isEditing = ref.watch(bioEditingProvider);

    final bioState = ref.watch(bioFormViewModelProvider);
    final bioVm = ref.read(bioFormViewModelProvider.notifier);

    final isSaving = bioState.isLoading;

    return BioSection(
      titleKey: 'profile_bio',
      bio: bio,
      emptyHintKey: 'bio_empty_hint',
      isEditing: isEditing,
      isSaving: isSaving,

      onEdit: () {
        bioVm.init(bio);
        ref.read(bioEditingProvider.notifier).state = true;
      },

      onCancel: () {
        ref.read(bioEditingProvider.notifier).state = false;
        bioVm.init(bio); // يرجّع القيمة الأصلية
      },

      onChanged: bioVm.onChanged,

      // ✅ النسخة القديمة: saveBio مع context
      onSave: () async {
        await bioVm.saveBio(context);

        // بعد الحفظ سكّري وضع التعديل
        ref.read(bioEditingProvider.notifier).state = false;
      },
    );
  }
}
