import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:notes_tasks/core/shared/widgets/common/app_snackbar.dart';
import 'package:notes_tasks/modules/profile/presentation/providers/skill/skills_provider.dart';
import 'package:notes_tasks/modules/profile/presentation/viewmodels/skill/skills_form_viewmodel.dart';
import 'package:notes_tasks/modules/profile/presentation/widgets/skills/profile_skill_section.dart';

class SkillsSectionContainer extends ConsumerStatefulWidget {
  const SkillsSectionContainer({super.key});

  @override
  ConsumerState<SkillsSectionContainer> createState() =>
      _SkillsSectionContainerState();
}

class _SkillsSectionContainerState
    extends ConsumerState<SkillsSectionContainer> {
  @override
  void initState() {
    super.initState();

    ref.listen<AsyncValue<SkillsFormState>>(
      skillsFormViewModelProvider,
      (prev, next) {
        final wasLoading = prev?.isLoading ?? false;

        next.when(
          data: (_) {
            if (!wasLoading) return;
            if (!mounted) return;

            AppSnackbar.show(context, 'skills_updated_success'.tr());
          },
          loading: () {},
          error: (e, st) {
            if (!wasLoading) return;
            if (!mounted) return;

            AppSnackbar.show(
              context,
              'failed_with_error'.tr(namedArgs: {'error': e.toString()}),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final profileSkills = ref.watch(skillsProvider);

    final asyncState = ref.watch(skillsFormViewModelProvider);
    final vm = ref.read(skillsFormViewModelProvider.notifier);

    final vmState = asyncState.value ?? const SkillsFormState();
    final isEditing = vmState.isEditing;
    final isSaving = asyncState.isLoading;

    final displayedSkills = isEditing ? vmState.skills : profileSkills;

    return ProfileSkillsSection(
      titleKey: 'skills_title',
      skills: displayedSkills,
      isEditing: isEditing,
      isSaving: isSaving,
      onEdit: () => vm.startEditing(profileSkills),
      onCancel: () => vm.cancelEditing(),
      onSave: () => vm.saveSkills(),
      onAddSkill: vm.addSkill,
      onRemoveSkillAt: vm.removeSkillAt,
    );
  }
}
