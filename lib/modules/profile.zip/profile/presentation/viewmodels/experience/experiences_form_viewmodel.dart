import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:notes_tasks/modules/profile/domain/usecases/experience/add_experience_usecase.dart';
import 'package:notes_tasks/modules/profile/domain/usecases/experience/update_experience_usecase.dart';
import 'package:notes_tasks/modules/profile/domain/usecases/experience/delete_experience_usecase.dart';

final experienceFormViewModelProvider =
    AsyncNotifierProvider<ExperienceFormViewModel, void>(
  ExperienceFormViewModel.new,
);

class ExperienceFormViewModel extends AsyncNotifier<void> {
  late final AddExperienceUseCase _addExperienceUseCase =
      ref.read(addExperienceUseCaseProvider);
  late final UpdateExperienceUseCase _updateExperienceUseCase =
      ref.read(updateExperienceUseCaseProvider);
  late final DeleteExperienceUseCase _deleteExperienceUseCase =
      ref.read(deleteExperienceUseCaseProvider);

  @override
  FutureOr<void> build() async {}

  Future<void> addExperience({
    required String title,
    required String company,
    DateTime? startDate,
    DateTime? endDate,
    required String location,
    required String description,
  }) async {
    if (state.isLoading) return;

    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      await _addExperienceUseCase(
        title: title.trim(),
        company: company.trim(),
        startDate: startDate,
        endDate: endDate,
        location: location.trim(),
        description: description.trim(),
      );
    });
  }

  Future<void> updateExperience({
    required String id,
    required String title,
    required String company,
    DateTime? startDate,
    DateTime? endDate,
    required String location,
    required String description,
  }) async {
    if (state.isLoading) return;

    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      await _updateExperienceUseCase(
        id: id,
        title: title.trim(),
        company: company.trim(),
        startDate: startDate,
        endDate: endDate,
        location: location.trim(),
        description: description.trim(),
      );
    });
  }

  Future<void> deleteExperience({required String id}) async {
    if (state.isLoading) return;

    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      await _deleteExperienceUseCase(id);
    });
  }

  void reset() {
    state = const AsyncData(null);
  }
}
