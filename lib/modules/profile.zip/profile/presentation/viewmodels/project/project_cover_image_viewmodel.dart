import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';

final projectCoverImageViewModelProvider = StateNotifierProviderFamily<
    ProjectCoverImageViewModel, AsyncValue<Uint8List?>, String>(
  (ref, projectId) => ProjectCoverImageViewModel(projectId),
);

class ProjectCoverImageViewModel extends StateNotifier<AsyncValue<Uint8List?>> {
  ProjectCoverImageViewModel(this._projectId)
      : super(const AsyncValue.loading()) {
    _loadInitial();
  }

  final String _projectId;
  static const _prefix = 'project_cover_';

  String get _key => '$_prefix$_projectId';

  Future<void> _loadInitial() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final base64 = prefs.getString(_key);

      if (base64 == null) {
        state = const AsyncValue.data(null);
        return;
      }

      try {
        state = AsyncValue.data(base64Decode(base64));
      } catch (_) {
        // لو المخزون خربان
        state = const AsyncValue.data(null);
      }
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> saveCover(Uint8List bytes) async {
    // ✅ لا context ولا snackbar
    state = const AsyncValue.loading();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, base64Encode(bytes));
      state = AsyncValue.data(bytes);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> clear() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_key);
      state = const AsyncValue.data(null);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}
