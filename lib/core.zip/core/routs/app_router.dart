import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:notes_tasks/core/providers/firebase/auth/user_role_provider.dart';

import 'package:notes_tasks/core/routs/app_routes.dart';
import 'package:notes_tasks/core/providers/firebase/auth/auth_state_provider.dart';
import 'package:notes_tasks/core/layouts/app_layouts.dart';

import 'package:notes_tasks/core/widgets/loading_indicator.dart';

// AUTH SCREENS
import 'package:notes_tasks/modules/auth/presentation/screens/login_screen.dart';
import 'package:notes_tasks/modules/auth/presentation/screens/email_verfication.dart';
import 'package:notes_tasks/modules/auth/presentation/screens/register.dart';
import 'package:notes_tasks/modules/auth/presentation/screens/reset_password.dart';
import 'package:notes_tasks/modules/profile/presentation/screens/profile_screen.dart';

import 'package:notes_tasks/modules/users/presentation/features/user_details/screens/user_section_details_view.dart';
import 'package:notes_tasks/modules/users/presentation/features/user_details/user_section_details_args.dart';

final goRouterProvider = Provider<GoRouter>((ref) {
  final authAsync = ref.watch(authStateProvider);
  final roleAsync = ref.watch(userRoleProvider);

  return GoRouter(
    initialLocation: AppRoutes.loading,

    routes: [
      // ---------------------------
      // Loading
      // ---------------------------
      GoRoute(
        path: AppRoutes.loading,
        builder: (context, state) =>
            const LoadingIndicator(withBackground: true),
      ),

      // ---------------------------
      // AUTH
      // ---------------------------
      GoRoute(
        path: AppRoutes.login,
        builder: (_, __) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (_, __) => const RegisterScreen(),
      ),
      GoRoute(
        path: AppRoutes.resetPassword,
        builder: (_, __) => const ResetPasswordScreen(),
      ),
      GoRoute(
        path: AppRoutes.verifyEmail,
        builder: (_, __) => const VerifyEmailScreen(),
      ),

      // ---------------------------
      // CLIENT SHELL
      // ---------------------------
      ShellRoute(
        builder: (_, __, child) => ClientShell(child: child),
        routes: [
          GoRoute(
            path: AppRoutes.clientJobs,
            builder: (_, __) => const PlaceholderScreen(title: 'Client Jobs'),
          ),
          GoRoute(
            path: AppRoutes.clientChats,
            builder: (_, __) => const PlaceholderScreen(title: 'Client Chats'),
          ),
          GoRoute(
            path: AppRoutes.clientProfile,
            builder: (_, __) => const ProfileScreen(),
          ),
        ],
      ),

      // ---------------------------
      // FREELANCER SHELL
      // ---------------------------
      ShellRoute(
        builder: (_, __, child) => FreelancerShell(child: child),
        routes: [
          GoRoute(
            path: AppRoutes.freelancerJobs,
            builder: (_, __) =>
                const PlaceholderScreen(title: 'Freelancer Jobs'),
          ),
          GoRoute(
            path: AppRoutes.freelancerProposals,
            builder: (_, __) =>
                const PlaceholderScreen(title: 'Freelancer Proposals'),
          ),
          GoRoute(
            path: AppRoutes.freelancerChats,
            builder: (_, __) =>
                const PlaceholderScreen(title: 'Freelancer Chats'),
          ),
          GoRoute(
            path: AppRoutes.freelancerProfile,
            builder: (_, __) => const ProfileScreen(),
          ),
        ],
      ),

      // ---------------------------
      // ADMIN
      // ---------------------------
      GoRoute(
        path: AppRoutes.adminDashboard,
        builder: (_, __) => const AdminDashboardScreen(),
      ),

      // ---------------------------
      // SHARED DETAILS
      // ---------------------------
      GoRoute(
        path: AppRoutes.userSectionDetails,
        builder: (_, state) {
          final args = state.extra as UserSectionDetailsArgs;
          return UserSectionDetailsView(
            title: args.title,
            provider: args.provider,
            mapper: args.mapper,
          );
        },
      ),
    ],

    // ===============================================
    // REDIRECT LOGIC
    // ===============================================
    redirect: (context, state) {
      final loc = state.uri.path;

      final isAuthRoute = loc == AppRoutes.login ||
          loc == AppRoutes.register ||
          loc == AppRoutes.resetPassword ||
          loc == AppRoutes.verifyEmail;

      final isSharedDetails = loc == AppRoutes.userSectionDetails;

      // ============ AUTH LOADING ============
      if (authAsync.isLoading) {
        // خليه على صفحة اللودينغ لو هو أصلاً هناك
        return loc == AppRoutes.loading ? null : AppRoutes.loading;
      }

      // AUTH ERROR
      if (authAsync.hasError) return AppRoutes.login;

      final user = authAsync.value;

      // ============ LOGGED OUT ============
      if (user == null) {
        // لو في أي مكان غير شاشات auth → رجّعه على login
        if (!isAuthRoute) {
          return AppRoutes.login;
        }
        // لو هو أصلاً على login/register/reset/verify → خليه
        return null;
      }

      // ============ EMAIL NOT VERIFIED ============
      if (!user.emailVerified && loc != AppRoutes.verifyEmail) {
        // أي مكان غير verify-email → ودّيه على verify-email
        return AppRoutes.verifyEmail;
      }

      // ============ ROLE LOADING ============
      if (roleAsync.isLoading) {
        // أثناء تحميل الدور، نعرض شاشة اللودينغ
        return loc == AppRoutes.loading ? null : AppRoutes.loading;
      }

      if (roleAsync.hasError) return AppRoutes.login;

      final role = roleAsync.value;
      if (role == null) return AppRoutes.login;

      final isClient = loc.startsWith('/client');
      final isFreelancer = loc.startsWith('/freelancer');
      final isAdmin = loc.startsWith('/admin');

      // ============ لو الإيميل اتفعّل ولساتنا على صفحة التفعيل ============
      if (user.emailVerified && loc == AppRoutes.verifyEmail) {
        switch (role) {
          case 'client':
            return AppRoutes.clientJobs;
          case 'freelancer':
            return AppRoutes.freelancerJobs;
          case 'admin':
            return AppRoutes.adminDashboard;
        }
      }

      // ============ دخل على auth route / loading / root وهو مسجل دخول ============
      if (isAuthRoute || loc == AppRoutes.loading || loc == '/') {
        switch (role) {
          case 'client':
            return AppRoutes.clientJobs;
          case 'freelancer':
            return AppRoutes.freelancerJobs;
          case 'admin':
            return AppRoutes.adminDashboard;
        }
      }

      // ============ BLOCK OTHER AREAS ============
      // اسمح بالـ shared route لكل الرولز (بس للمستخدمين المسجلين)
      if (!isSharedDetails) {
        if (role == 'client' && !isClient) {
          return AppRoutes.clientJobs;
        }

        if (role == 'freelancer' && !isFreelancer) {
          return AppRoutes.freelancerJobs;
        }

        if (role == 'admin' && !isAdmin) {
          return AppRoutes.adminDashboard;
        }
      }

      return null;
    },
  );
});
