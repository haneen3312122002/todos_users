class AppRoutes {
  // AUTH
  static const String loading = '/loading';
  static const String login = '/login';
  static const String verifyEmail = '/verify-email';
  static const String register = '/register';
  static const String resetPassword = '/reset-pass';

  // =======================
  // CLIENT
  // =======================
  static const String clientJobs = '/client/jobs';
  static const String clientChats = '/client/chats';
  static const String clientProfile = '/client/profile'; // ✅ عدلناها

  // =======================
  // FREELANCER
  // =======================
  static const String freelancerJobs = '/freelancer/jobs';
  static const String freelancerProposals = '/freelancer/proposals';
  static const String freelancerChats = '/freelancer/chats';
  static const String freelancerProfile = '/freelancer/profile'; // ✅ عدلناها

  // =======================
  // ADMIN
  // =======================
  static const String adminDashboard = '/admin/dashboard';

  // =======================
  // Other shared routes
  // =======================
  static const String userSectionDetails = '/user-section-details';
}
