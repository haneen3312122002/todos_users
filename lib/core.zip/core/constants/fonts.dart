class AppFonts {
  //  Primary font family used across the app
  static const String primaryFont = 'Poppins';

  // secondary font (for headings or special text)
  static const String secondaryFont = 'Roboto';
}
