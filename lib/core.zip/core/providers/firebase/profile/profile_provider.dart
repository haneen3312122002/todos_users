import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/core/providers/firebase/firebase_providers.dart';
import 'package:notes_tasks/core/services/firebase/profile_service/profile_service.dart';

final profileServiceProvider = Provider<ProfileService>((ref) {
  return ProfileService(
    auth: ref.read(firebaseAuthProvider),
    db: ref.read(firebaseFirestoreProvider),
    storage: ref.read(firebaseStorageProvider),
  );
});
