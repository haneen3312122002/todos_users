import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:notes_tasks/core/data/remote/firebase/providers/firebase_providers.dart';

final userRoleProvider = FutureProvider<String?>((ref) async {
  final auth = ref.watch(firebaseAuthProvider);
  final db = ref.watch(firebaseFirestoreProvider);

  final user = auth.currentUser;
  if (user == null) return null;

  final doc = await db.collection('users').doc(user.uid).get();
  if (!doc.exists) return null;

  final data = doc.data();
  if (data == null) return null;

  final role = data['role'];
  if (role is String) return role;

  return null;
});