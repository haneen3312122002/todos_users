import 'package:flutter_riverpod/legacy.dart';

final navIndexProvider = StateProvider<int>((ref) => 0);