import 'package:flutter_riverpod/legacy.dart';

final expandedUserProvider = StateProvider<Map<int, bool>>((ref) => {});