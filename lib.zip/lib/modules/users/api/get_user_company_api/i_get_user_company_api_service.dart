abstract class IGetUserCompanyApiService {
  
  Future<Map<String, dynamic>> getUserCompany(int id);
}