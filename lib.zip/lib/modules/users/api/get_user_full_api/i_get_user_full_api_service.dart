abstract class IGetUserFullApiService {
  
  Future<Map<String, dynamic>> getUserFull(int id);
}