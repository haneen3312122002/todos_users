enum ProposalStatus { pending, accepted, rejected }
